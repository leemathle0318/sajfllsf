"""Prepare only this project's staging profile and the pinned Theos packager.

No phone access, no recursive ownership changes, no weakening of package checks.
"""
import argparse
import hashlib
import os
import plistlib
import stat
import tempfile
from pathlib import Path

DM_SHA256 = "a750fda6e9a2306b6c2b8b099e21aeca56b314179c0cd3b73c7c8636b32f5d41"
OLD = b'$tf->chown("root", "wheel");'
NEW = OLD + b'\n\t\t\t\t\t# OBSBridge: numeric owners must agree with the root/wheel names.\n\t\t\t\t\t$tf->uid(0);\n\t\t\t\t\t$tf->gid(0);'
PROFILE = "local.xiaoguai.obsbridge.media-read.plist"
MEDIA = "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v4.dat"


def patch_dm(path, expected_hash=DM_SHA256):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError("Theos dm.pl must be a regular file")
    raw = path.read_bytes()
    if NEW in raw:
        original = raw.replace(NEW, OLD)
        if raw.count(NEW) != 1 or hashlib.sha256(original).hexdigest() != expected_hash:
            raise ValueError("unexpected already-patched Theos dm.pl")
        return False
    if hashlib.sha256(raw).hexdigest() != expected_hash or raw.count(OLD) != 1:
        raise ValueError("unsupported Theos dm.pl: expected pinned submodule d9a3b72e274226dd2823c0a7c1d6d05099f4f51c")
    path.write_bytes(raw.replace(OLD, NEW))
    return True


def prepare_profile(stage, profile=PROFILE, process="com.apple.mediaserverd"):
    base = Path(stage).absolute()
    if not base.resolve().is_relative_to(Path.cwd().resolve()) or base.resolve() == Path.cwd().resolve():
        raise ValueError("staging directory must be inside this project")
    candidates = [base, base / "Library", base / "Library/libSandy"]
    if any(p.is_symlink() or not p.is_dir() for p in candidates):
        raise ValueError("invalid staging directories")
    path = candidates[-1] / profile
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError("staged profile must be a regular single-link file")
    rule = plistlib.loads(path.read_bytes())
    if rule.get("AllowedProcesses") != [process] or rule.get("Extensions") != [
        {"type": "file", "extension_class": "com.apple.app-sandbox.read", "path": MEDIA}]:
        raise ValueError("staged profile permission scope changed")
    # Convert before chmod, so Theos' later plutil pass will skip this file
    # instead of recreating it with a different mode/umask.
    raw = plistlib.dumps(rule, fmt=plistlib.FMT_BINARY, sort_keys=False)
    fd, temporary = tempfile.mkstemp(prefix=".obsbridge-profile-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    os.chmod(path.parent, 0o755)
    return path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--patch-theos")
    group.add_argument("--stage")
    args = parser.parse_args()
    try:
        if args.patch_theos:
            changed = patch_dm(args.patch_theos)
            print("PASS: pinned dm.pl numeric UID/GID=0 correction", "applied" if changed else "already applied")
        else:
            path = prepare_profile(args.stage)
            prepare_profile(args.stage, "local.xiaoguai.obsbridge.live-read.plist", "com.zhiliaoapp.musically")
            print("PASS: staged libSandy profile is binary plist, mode 0644:", path)
    except (ValueError, OSError, plistlib.InvalidFileException) as error:
        raise SystemExit("PACKAGING PREPARATION FAILED: " + str(error))
