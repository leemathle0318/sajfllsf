# 第三方依赖与源码

## 0.2.0 设计参考与边界

系统 `BWNodeOutput emitSampleBuffer:` 接入点参考 EthanArbuckle/vcam-ios 的公开示例；进程分离、IOSurface/PCM 共享与按阶段诊断的设计对照 GUSHU101/VCamLab-2.0。仅参考公开接口/架构，本版 SharedMedia 协议、租约、TCP 接收及混音代码自行实现，不复制参考项目的媒体实现或二进制。它们的 README/测试清单不构成本版的设备测试结果。具体参考链接与功能差异见 README。

- 本工程不包含用户提供的 VCam 二进制，也不提取或复制它的实现。
- FFmpeg 7.1.5 官方源码：https://ffmpeg.org/releases/ffmpeg-7.1.5.tar.xz
- 实际下载文件 SHA-256：`de668509caf9e35e3cd162473441fdb29538c6d96ed080292b3cf9e6fc5d558f`。
- `scripts/build_ffmpeg.sh` 不启用 GPL、nonfree 或 libx264；仅构建 H.264/AAC 解码、MPEG-TS 解复用、缩放和重采样，以及苹果 VideoToolbox 硬件解码接口。
- FFmpeg 的许可证和配置说明来自其源码中的 `COPYING.LGPLv2.1`、`LICENSE.md`。工作流将它们与原始源码包、静态库、插件对象文件一并附在构建产物中。分发编译结果时请保留这些材料，并提供本工程完整对应源码及构建方法，方便替换 LGPL 组件和重新链接。
- Theos、SDK 和注入框架的许可证分别以各自项目为准。本压缩包不附带苹果 SDK。
- OBS / FFmpeg 电脑端的编码器与本插件中的解码库是两套独立依赖。

参考：
- https://ffmpeg.org/legal.html
- https://theos.dev/docs/rootless
- https://theos.dev/docs/arm64e-deployment

## 0.2.4 外部授权依赖：libSandy

实际审查 opa334/libSandy 提交 `9c77311172485e92bf0c439391be5a9565c877e4`，MIT Copyright (c) 2022 Lars Fröder，原许可保留于 LICENSE-libSandy.txt。只调用设备安装的公开接口，不捆绑二进制或复制沙盒扩展签发实现。

公开源码：https://github.com/opa334/libSandy 。profile/异步适配器与访问探测由本工程实现，作用域仅媒体进程读取插件自有单个缓存文件。上游能够提供接口不证明当前设备实际接受扩展。

VCamLab-2.0 与 EthanArbuckle/vcam-ios 审查树未发现许可证，仅研究接口/架构，不直接搬媒体实现；notaudren/VCam-iOS-16 审查树只有 README。审查记录见 SOURCE_REVIEW.md。

## 打包器补丁

本源码只附自写校验/补丁脚本，不捆绑或重新分发 dm.pl/Archive::Tar。Actions 下载固定上游源码，脚本核对完整哈希后仅修 tar 数字属主。原上游许可仍随原仓库保留；补丁记录见 PACKAGING_FIX.md。
