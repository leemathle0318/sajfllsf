#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/LiveAudio.hpp"
#include "../core/SharedMedia.hpp"
#include <cassert>
#include <cstdio>
#include <memory>
#include <vector>

int main() {
    constexpr uint32_t auou=0x61756f75, rioc=0x72696f63, vpio=0x7670696f, apple=0x6170706c;
    assert(obs::liveInput(auou,rioc,apple,1,0)); assert(obs::liveInput(auou,vpio,apple,1,0));
    assert(!obs::liveInput(auou,rioc,apple,0,0)); assert(!obs::liveInput(auou,rioc,apple,1,-1));
    assert(!obs::liveInput(auou,0,apple,1,0)); assert(!obs::liveInput(0,rioc,apple,1,0));
    assert(!obs::liveInput(auou,rioc,0,1,0));
    for (int status : {0,-50,-10874}) for (bool eligible : {false,true}) for (bool didMix : {false,true}) {
        uint32_t flags=0x1010; unsigned originals=0, mixers=0;
        int result=obs::liveRender([&] { ++originals; return status; }, [&] { ++mixers; return didMix; }, &flags, 0x10, eligible);
        assert(result==status && originals==1);
        assert(mixers == unsigned(!status && eligible));
        assert(flags == (!status && eligible && didMix ? 0x1000u : 0x1010u));
    }
    assert(obs::liveRender([]{return 0;},[]{return true;},nullptr,16,true)==0);
    auto bus=std::make_unique<obs::SharedMedia>(); bus->initialize(); bus->enabled=1;
    bus->generation=1; bus->heartbeatUS=1000000;
    obs::NativePCM pcm; pcm.bits=16; pcm.bytes=2; pcm.frameBytes=4; pcm.channels=2; pcm.signedInteger=true;
    std::vector<int16_t> stereo(2048); std::vector<float> source(1024,.20f), scratch(1024);
    obs::AudioDeliveryCursor cursor;
    for (unsigned pull=0;pull<200;++pull) {
        double now=1.+pull*1024./48000.; bus->heartbeatUS=uint64_t(now*1e6);
        double when=cursor.begin(91,1,now,1024,48000);
        bus->writeAudio(source.data(),source.size(),when);
        for (size_t i=0;i<1024;++i) { stereo[2*i]=3277; stereo[2*i+1]=-3277; }
        obs::PCMBuffer buffer{stereo.data(),stereo.size()*sizeof(int16_t),2};
        uint32_t flags=16;
        auto mixer=[&] {
            if (!bus->readAudio(scratch.data(),1024,when,48000,uint64_t(now*1e6))) return false;
            return obs::mixNative(scratch.data(),&buffer,1,1024,pcm,1.,.70);
        };
        assert(!obs::liveRender([]{return 0;},mixer,&flags,16,true)); assert(!(flags&16));
        // Last fractional interpolation sample can be zero when unfilled; test
        // the middle of the buffer, both distinct mic channels preserved.
        assert(stereo[1024]>7800 && stereo[1024]<8000);
        assert(stereo[1025]>1200 && stereo[1025]<1400);
    }
    auto prior=stereo; bus->audioReady=0;
    assert(!bus->readAudio(scratch.data(),1024,6.,48000,6000000)); assert(stereo==prior);
    obs::PCMBuffer shortBuffer{stereo.data(),3,2};
    assert(!obs::mixNative(source.data(),&shortBuffer,1,1024,pcm,1.,.70)); assert(stereo==prior);
    obs::PullIdentity identity;
    assert(!identity.duplicate(true,1024,true,7,1024,2));
    identity.accept(true,1024,true,7,1024,2);
    assert(identity.duplicate(true,1024,true,7,1024,2));
    assert(!identity.duplicate(true,2048,true,8,1024,2));
    assert(!identity.duplicate(true,1024,true,7,1024,4));
    assert(!identity.duplicate(false,0,false,0,1024,2));
    std::puts("PASS: live I/O/bus/status gate; original once/status/flags; 200 native 48k stereo pulls; mic channel preservation; underflow/bounds; duplicate identity (not a phone uplink test)");
}
