#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/NativePCM.hpp"
#include "../core/SharedMedia.hpp"
#include <cassert>
#include <cstdio>
#include <limits>
#include <memory>
#include <vector>
#include <utility>

static void checkFormat(obs::NativePCM f) {
    assert(f.valid());
    std::vector<uint8_t> a(f.frameBytes * 4 + 8, 0x5a), b(f.frameBytes * 4 + 8, 0x5a);
    obs::PCMBuffer buffers[] = {{a.data(), f.frameBytes * 4, f.planar ? 1u : f.channels},
        {b.data(), f.frameBytes * 4, 1}};
    size_t n = f.planar ? f.channels : 1;
    float program[] = {.2f, -.2f, .2f, -3.f};
    double mic[] = {.25, -.25, .95, -.95};
    for (size_t plane = 0; plane < n; ++plane)
        for (unsigned i = 0; i < 4; ++i) for (unsigned channel = 0; channel < buffers[plane].channels; ++channel)
            obs::pcmWrite(static_cast<uint8_t *>(buffers[plane].data) + i * f.frameBytes + channel * f.bytes, f, mic[i]);
    assert(obs::mixNative(program, buffers, n, 4, f, 1., .70));
    double expected[] = {.39, -.39, 1., -1.};
    for (size_t plane = 0; plane < n; ++plane)
        for (unsigned i = 0; i < 4; ++i) for (unsigned channel = 0; channel < buffers[plane].channels; ++channel) {
            double result = obs::pcmRead(static_cast<uint8_t *>(buffers[plane].data) + i * f.frameBytes + channel * f.bytes, f);
            assert(std::fabs(result - expected[i]) < .0001);
        }
    for (unsigned i = 0; i < 8; ++i) {
        assert(a[f.frameBytes * 4 + i] == 0x5a); assert(b[f.frameBytes * 4 + i] == 0x5a);
    }
}
int main() {
    unsigned formats = 0;
    for (bool planar : {false, true}) for (bool big : {false, true}) {
        for (auto pair : {std::pair<unsigned, unsigned>{16,2}, {24,3}, {24,4}, {32,4}}) {
            for (bool high : {false, true}) {
                obs::NativePCM f; f.bits = pair.first; f.bytes = pair.second;
                f.signedInteger = true; f.channels = 2; f.planar = planar; f.bigEndian = big; f.highAligned = high;
                f.frameBytes = f.bytes * (planar ? 1 : 2);
                checkFormat(f); ++formats;
            }
        }
        for (unsigned bits : {32u,64u}) {
            obs::NativePCM f; f.bits = bits; f.bytes = bits / 8; f.frameBytes = f.bytes * (planar ? 1 : 2);
            f.channels = 2; f.planar = planar; f.bigEndian = big; f.floating = true;
            checkFormat(f); ++formats;
        }
        obs::NativePCM fixed; fixed.bits = 32; fixed.bytes = 4; fixed.frameBytes = 4 * (planar ? 1 : 2);
        fixed.channels = 2; fixed.signedInteger = true; fixed.planar = planar; fixed.bigEndian = big; fixed.fractionBits = 24;
        checkFormat(fixed); ++formats;
    }
    obs::NativePCM f; f.bits = 32; f.bytes = f.frameBytes = 4; f.channels = 1; f.floating = true;
    float mic[] = {.2f, .3f}; float program[] = {.1f, .1f};
    obs::PCMBuffer shortBuffer{mic, 1, 1};
    assert(!obs::mixNative(program, &shortBuffer, 1, 2, f, 1., .70)); assert(mic[0] == .2f);
    f.fractionBits = 24; assert(!f.valid()); f.fractionBits = 0;
    float nan = std::numeric_limits<float>::quiet_NaN();
    assert(obs::pcmRead(reinterpret_cast<uint8_t *>(&nan), f) == 0);
    // Independent known bytes prevent matching read/write bugs hiding errors.
    obs::NativePCM integer; integer.bits = 24; integer.bytes = integer.frameBytes = 3;
    integer.channels = 1; integer.signedInteger = true;
    const uint8_t positive24[] = {0,0,0x40}, negative24[] = {0,0,0xc0};
    assert(obs::pcmRead(positive24, integer) == .5);
    assert(obs::pcmRead(negative24, integer) == -.5);
    integer.bytes = integer.frameBytes = 4; integer.highAligned = true;
    const uint8_t padded24[] = {0x99,0,0,0x40};
    assert(obs::pcmRead(padded24, integer) == .5);
    integer.bits = 32; integer.highAligned = false; integer.fractionBits = 24;
    const uint8_t fixed24[] = {0,0,0x80,0};
    assert(obs::pcmRead(fixed24, integer) == .5);
    // Both independently identifiable sources survive a one-second mix.
    constexpr size_t frames = 48000; constexpr double pi = 3.141592653589793;
    std::vector<float> native(frames), programTone(frames);
    for (size_t i = 0; i < frames; ++i) {
        native[i] = float(.15 * std::sin(2*pi*880*i/48000));
        programTone[i] = float(.25 * std::sin(2*pi*440*i/48000));
    }
    for (size_t start = 0; start < frames; start += 1000) {
        obs::PCMBuffer buffer{native.data()+start, 1000*sizeof(float), 1};
        assert(obs::mixNative(programTone.data()+start, &buffer, 1, 1000, f, 1., .70));
    }
    double micAmplitude = 0, obsAmplitude = 0;
    for (size_t i = 0; i < frames; ++i) {
        micAmplitude += native[i] * std::sin(2*pi*880*i/48000);
        obsAmplitude += native[i] * std::sin(2*pi*440*i/48000);
    }
    assert(std::fabs(micAmplitude*2/frames - .15) < .0001);
    assert(std::fabs(obsAmplitude*2/frames - .175) < .0001);

    obs::AudioDeliveryCursor cursor;
    assert(cursor.begin(77,1,10,480,48000) == 10);
    assert(std::fabs(cursor.begin(77,1,10.014,480,48000)-10.010) < .00001);
    assert(std::fabs(cursor.begin(77,1,10.019,480,48000)-10.020) < .00001);
    assert(cursor.begin(77,2,11,480,48000) == 11); // new stream generation
    assert(cursor.begin(78,2,12,441,44100) == 12); // session and rate
    assert(cursor.begin(78,2,13,441,44100) == 13); // a long callback gap resyncs
    assert(std::isnan(cursor.begin(78,2,13,0,44100)));
    auto bus = std::make_unique<obs::SharedMedia>();
    bus->initialize(); bus->enabled = 1; bus->generation = 1; bus->heartbeatUS = 10000000;
    bus->writeAudio(program,2,10);
    float source[2]{};
    assert(!bus->readAudio(source,2,9.8,48000,10000000)); // old mic PTS misses current OBS data
    assert(bus->readAudio(source,2,10,48000,10000000)); // actual host delivery cursor hits it
    std::printf("PASS: %u native PCM layout/endian/bit-depth cases, 24-bit padding, fixed 8.24, float64, bounds/clipping/NaN; mic 880Hz + OBS 440Hz amplitudes; host-clock cursor/rate/reset (not a phone test)\n",formats);
}
