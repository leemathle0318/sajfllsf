#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace obs {
struct VideoPlane {
    const uint8_t *source;
    uint8_t *target;
    size_t sourceStride, targetStride, height, bytes;
};
inline bool copyVideoPlanes(const VideoPlane *planes, size_t count) {
    if (!planes || !count || count > 2) return false;
    for (size_t i = 0; i < count; ++i) {
        const auto &p = planes[i];
        if (!p.source || !p.target || !p.height || !p.bytes || p.sourceStride < p.bytes ||
            p.targetStride < p.bytes || p.sourceStride > SIZE_MAX / p.height ||
            p.targetStride > SIZE_MAX / p.height) return false;
    }
    // Preflight both NV12 planes, then write only visible pixels, never padding.
    for (size_t i = 0; i < count; ++i) {
        const auto &p = planes[i];
        for (size_t y = 0; y < p.height; ++y)
            memcpy(p.target + y * p.targetStride, p.source + y * p.sourceStride, p.bytes);
    }
    return true;
}
}
