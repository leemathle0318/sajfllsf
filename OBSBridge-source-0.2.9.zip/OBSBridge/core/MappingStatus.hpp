#pragma once
#include <cstdint>
namespace obs {
enum class MappingCode : uint32_t {
    Unreported = 0, MissingID, LookupFailed, MissingBase, Alignment,
    AllocationSize, Magic, Version, ProtocolSize, Notification, Ready,
    FileOpen, FileStat, FileMap, FilePermissions, Cookie
};
constexpr uint64_t mappingState(MappingCode code, uint32_t detail) {
    return (uint64_t(code) << 32) | detail;
}
constexpr MappingCode mappingCode(uint64_t state) { return MappingCode(state >> 32); }
constexpr uint32_t mappingDetail(uint64_t state) { return uint32_t(state); }
}
