#import "Receiver.h"
#import "Shared.h"
#import "LiveAudioStatus.h"
#include "core/VideoBudget.hpp"
#import "MediaBus.h"
#import <CoreImage/CoreImage.h>
#include "core/Timeline.hpp"
#include "core/NonblockingRead.hpp"
#include "core/PendingFrames.hpp"
#include <atomic>
#include <array>
#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/hwcontext.h>
#include <libavutil/pixdesc.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

namespace {
void waitNetwork(void) {
    timespec delay{0, 10000000}; // 10 ms, no busy spinning
    nanosleep(&delay, nullptr);
}
bool nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    return flags >= 0 && fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}
struct Image {
    CVPixelBufferRef pixel;
    double due;
    Image(CVPixelBufferRef p, double d) : pixel(CVPixelBufferRetain(p)), due(d) {}
    ~Image() { CVPixelBufferRelease(pixel); }
};
struct Engine {
    std::atomic<bool> enabled{false}, listening{false};
    std::atomic<uint64_t> generation{0}, videos{0}, audios{0}, bytes{0}, accepted{0}, rejected{0}, published{0}, publishFailed{0};
    std::atomic<uint64_t> ticks{0}, clockResets{0}, queueDrops{0}, budgetDrops{0}, hardwareFrames{0}, softwareFrames{0};
    std::mutex mutex;
    std::string message = "尚未启用", lastError, lastPeer;
    std::deque<std::shared_ptr<Image>> images;
    std::shared_ptr<Image> current;
    bool clockValid = false;
    double originPTS = 0, originLocal = 0;
    std::shared_ptr<Image> publishedImage;
    dispatch_queue_t queue = dispatch_queue_create("local.xiaoguai.obsbridge.receive", DISPATCH_QUEUE_SERIAL);
    bool active(uint64_t g) { return enabled.load() && generation.load() == g; }
    void note(const char *s) { std::lock_guard<std::mutex> l(mutex); message = s; }
    void noteFor(uint64_t g, const char *s) {
        std::lock_guard<std::mutex> l(mutex);
        if (generation.load() == g) message = s;
    }
    void clearLocked() {
        images.clear(); current.reset(); publishedImage.reset(); clockValid = false; OBBusResetAudio();
    }
    // The same sender clock schedules both tracks, independent of network arrival jitter.
    double scheduleLocked(double pts) {
        double now = OBNow();
        if (!clockValid) { originPTS = pts; originLocal = now + .180; clockValid = true; }
        double due = originLocal + pts - originPTS;
        if (due < now - 1.0 || due > now + 1.0) {
            ++clockResets;
            clearLocked(); originPTS = pts; originLocal = now + .180; clockValid = true;
            due = originLocal;
        }
        return due;
    }
};
Engine &engine() { static Engine e; return e; }

struct Reader {
    int fd = -1;
    int receiveError = 0;
    uint64_t generation;
    double lastData = OBNow();
    explicit Reader(uint64_t g) : generation(g) {}
    ~Reader() { if (fd >= 0) close(fd); }
    static int read(void *opaque, uint8_t *data, int size) {
        auto &r = *static_cast<Reader *>(opaque);
        auto result = obs::nonblockingRead([&]{ return engine().active(r.generation); },
            [&]{
                ssize_t n = recv(r.fd, data, size, 0);
                int code = n < 0 ? errno : 0;
                return obs::ReadAttempt{int(n), code, code == EINTR, code == EAGAIN || code == EWOULDBLOCK};
            }, []{ return OBNow(); }, []{ waitNetwork(); }, r.lastData);
        if (result.end == obs::ReadEnd::Data) {
            r.lastData = OBNow(); engine().bytes += uint64_t(result.bytes); return result.bytes;
        }
        if (result.end == obs::ReadEnd::Eof) return AVERROR_EOF;
        if (result.end == obs::ReadEnd::Timeout) return AVERROR(ETIMEDOUT);
        if (result.end == obs::ReadEnd::Cancelled) return AVERROR_EXIT;
        r.receiveError = result.error;
        return AVERROR(result.error);
    }
    static int interrupt(void *opaque) {
        auto &r = *static_cast<Reader *>(opaque);
        return !engine().active(r.generation);
    }
};

struct Decoder {
    obs::FrameGate gate;
    AVCodecContext *ctx = nullptr;
    AVStream *stream = nullptr;
    AVFrame *frame = av_frame_alloc();
    SwrContext *swr = nullptr;
    SwsContext *sws = nullptr;
    int inputRate = 0;
    AVSampleFormat inputFormat = AV_SAMPLE_FMT_NONE;
    AVChannelLayout inputLayout{};
    ~Decoder() {
        avcodec_free_context(&ctx); av_frame_free(&frame);
        swr_free(&swr); sws_freeContext(sws); av_channel_layout_uninit(&inputLayout);
    }
    static AVPixelFormat pixelFormat(AVCodecContext *, const AVPixelFormat *formats) {
        for (auto p = formats; *p != AV_PIX_FMT_NONE; ++p)
            if (*p == AV_PIX_FMT_VIDEOTOOLBOX) return *p;
        for (auto p = formats; *p != AV_PIX_FMT_NONE; ++p) {
            auto d = av_pix_fmt_desc_get(*p);
            if (d && !(d->flags & AV_PIX_FMT_FLAG_HWACCEL)) return *p;
        }
        return AV_PIX_FMT_NONE;
    }
    bool open(AVFormatContext *fmt, AVMediaType type) {
        int i = av_find_best_stream(fmt, type, -1, -1, nullptr, 0);
        if (i < 0) return false;
        stream = fmt->streams[i];
        AVCodecID expected = type == AVMEDIA_TYPE_VIDEO ? AV_CODEC_ID_H264 : AV_CODEC_ID_AAC;
        if (stream->codecpar->codec_id != expected) return false;
        const AVCodec *codec = avcodec_find_decoder(expected);
        if (!codec || !frame || !(ctx = avcodec_alloc_context3(codec))) return false;
        if (avcodec_parameters_to_context(ctx, stream->codecpar) < 0) return false;
        ctx->pkt_timebase = stream->time_base;
        ctx->thread_count = 2;
        ctx->max_pixels = 1920 * 1080;
        if (type == AVMEDIA_TYPE_VIDEO) {
            if (av_hwdevice_ctx_create(&ctx->hw_device_ctx, AV_HWDEVICE_TYPE_VIDEOTOOLBOX,
                                      nullptr, nullptr, 0) >= 0) ctx->get_format = pixelFormat;
        }
        return avcodec_open2(ctx, codec, nullptr) >= 0;
    }
    double pts() {
        int64_t p = frame->best_effort_timestamp;
        if (p == AV_NOPTS_VALUE) p = frame->pts;
        return p == AV_NOPTS_VALUE ? NAN : p * av_q2d(stream->time_base);
    }
    void video(uint64_t g) {
        if (frame->width <= 0 || frame->height <= 0 || frame->width > 2048 ||
            frame->height > 2048 || int64_t(frame->width) * frame->height > 1920 * 1080) return;
        double p = pts(); if (!std::isfinite(p)) return;
        auto budget = obs::videoBudget(OBBusVideoProfile(), unsigned(NSProcessInfo.processInfo.thermalState));
        if (!gate.admit(p, budget.fps)) { ++engine().budgetDrops; return; }
        CVPixelBufferRef pixel = nullptr;
        bool owned = false;
        if (frame->format == AV_PIX_FMT_VIDEOTOOLBOX) { pixel = (CVPixelBufferRef)frame->data[3]; ++engine().hardwareFrames; }
        else {
            ++engine().softwareFrames;
            NSDictionary *attrs = @{(id)kCVPixelBufferIOSurfacePropertiesKey: @{}};
            if (CVPixelBufferCreate(kCFAllocatorDefault, frame->width, frame->height,
                    kCVPixelFormatType_32BGRA, (__bridge CFDictionaryRef)attrs, &pixel) != kCVReturnSuccess) return;
            owned = true;
            sws = sws_getCachedContext(sws, frame->width, frame->height, (AVPixelFormat)frame->format,
                    frame->width, frame->height, AV_PIX_FMT_BGRA, SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
            if (!sws || CVPixelBufferLockBaseAddress(pixel, 0) != kCVReturnSuccess) {
                CVPixelBufferRelease(pixel); return;
            }
            uint8_t *out[] = {(uint8_t *)CVPixelBufferGetBaseAddress(pixel), nullptr, nullptr, nullptr};
            int stride[] = {(int)CVPixelBufferGetBytesPerRow(pixel), 0, 0, 0};
            int rows = sws_scale(sws, frame->data, frame->linesize, 0, frame->height, out, stride);
            CVPixelBufferUnlockBaseAddress(pixel, 0);
            if (rows != frame->height) { CVPixelBufferRelease(pixel); return; }
        }
        if (pixel) {
            auto &e = engine(); std::lock_guard<std::mutex> l(e.mutex);
            if (e.active(g)) {
                double due = e.scheduleLocked(p);
                if (due >= OBNow() - .25 && due < OBNow() + .75) {
                    if (!obs::enqueuePending(e.images, std::make_shared<Image>(pixel, due))) ++e.queueDrops;
                    ++e.videos;
                }
            }
        }
        if (owned) CVPixelBufferRelease(pixel);
    }
    void audio(uint64_t g) {
        double p = pts();
        if (!std::isfinite(p) || frame->nb_samples <= 0 || frame->nb_samples > 8192 ||
            frame->sample_rate < 8000 || frame->sample_rate > 96000 ||
            frame->ch_layout.nb_channels < 1 || frame->ch_layout.nb_channels > 2) return;
        if (!swr || frame->sample_rate != inputRate || frame->format != inputFormat ||
            av_channel_layout_compare(&frame->ch_layout, &inputLayout)) {
            swr_free(&swr); av_channel_layout_uninit(&inputLayout);
            AVChannelLayout mono = AV_CHANNEL_LAYOUT_MONO;
            if (swr_alloc_set_opts2(&swr, &mono, AV_SAMPLE_FMT_FLT, obs::Timeline::Rate,
                    &frame->ch_layout, (AVSampleFormat)frame->format, frame->sample_rate, 0, nullptr) < 0 ||
                swr_init(swr) < 0) { swr_free(&swr); return; }
            av_channel_layout_copy(&inputLayout, &frame->ch_layout);
            inputRate = frame->sample_rate; inputFormat = (AVSampleFormat)frame->format;
        }
        int64_t delay = swr_get_delay(swr, inputRate);
        int count = (int)av_rescale_rnd(delay + frame->nb_samples, obs::Timeline::Rate, inputRate, AV_ROUND_UP);
        if (count <= 0 || count > 65536) return;
        std::vector<float> mono(count);
        uint8_t *out[] = {(uint8_t *)mono.data()};
        int n = swr_convert(swr, out, count, (const uint8_t **)frame->extended_data, frame->nb_samples);
        if (n <= 0) return;
        auto &e = engine(); std::lock_guard<std::mutex> l(e.mutex);
        if (e.active(g)) {
            double due = e.scheduleLocked(p) - double(delay) / inputRate;
            if (due > OBNow() - .25 && due < OBNow() + .75) {
                OBBusWriteAudio(mono.data(), n, due); ++e.audios;
            }
        }
    }
    void push(AVPacket *packet, uint64_t g, bool isVideo) {
        if (!ctx || packet->stream_index != stream->index) return;
        int rc = avcodec_send_packet(ctx, packet);
        if (rc == AVERROR(EAGAIN)) {
            while (avcodec_receive_frame(ctx, frame) >= 0) {
                @autoreleasepool { if (isVideo) video(g); else audio(g); }
                av_frame_unref(frame);
            }
            rc = avcodec_send_packet(ctx, packet);
        }
        if (rc < 0) return;
        while (avcodec_receive_frame(ctx, frame) >= 0) {
            @autoreleasepool { if (isVideo) video(g); else audio(g); }
            av_frame_unref(frame);
        }
    }
};

void decodeConnection(Reader &reader) {
    auto &e = engine();
    AVFormatContext *fmt = avformat_alloc_context();
    uint8_t *data = (uint8_t *)av_malloc(32768);
    AVIOContext *io = data ? avio_alloc_context(data, 32768, 0, &reader, Reader::read, nullptr, nullptr) : nullptr;
    if (!fmt || !io) {
        if (io) { av_freep(&io->buffer); avio_context_free(&io); } else av_free(data);
        avformat_free_context(fmt); e.noteFor(reader.generation, "内存不足"); return;
    }
    fmt->pb = io; fmt->flags |= AVFMT_FLAG_CUSTOM_IO;
    fmt->max_streams = 8;
    fmt->interrupt_callback = {Reader::interrupt, &reader};
    AVDictionary *opts = nullptr;
    av_dict_set(&opts, "probesize", "262144", 0);
    av_dict_set(&opts, "analyzeduration", "500000", 0);
    av_dict_set(&opts, "max_delay", "0", 0);
    av_dict_set(&opts, "format_whitelist", "mpegts", 0);
    av_dict_set(&opts, "codec_whitelist", "h264,aac", 0);
    int rc = avformat_open_input(&fmt, nullptr, av_find_input_format("mpegts"), &opts);
    av_dict_free(&opts);
    if (rc >= 0) rc = avformat_find_stream_info(fmt, nullptr);
    if (rc >= 0) {
        Decoder video, audio;
        bool v = video.open(fmt, AVMEDIA_TYPE_VIDEO), a = audio.open(fmt, AVMEDIA_TYPE_AUDIO);
        if (!v && !a) e.noteFor(reader.generation, "没有可解码的 H.264/AAC 轨道");
        else {
            e.noteFor(reader.generation, v && a ? "已连接，H.264/AAC 解码中" : "已连接，但缺视频或音频轨道，不满足完整功能");
            AVPacket *packet = av_packet_alloc();
            if (packet) {
                while (e.active(reader.generation) && av_read_frame(fmt, packet) >= 0) {
                    video.push(packet, reader.generation, true);
                    audio.push(packet, reader.generation, false);
                    av_packet_unref(packet);
                }
                av_packet_free(&packet);
            }
        }
    } else {
        char text[AV_ERROR_MAX_STRING_SIZE]{}; av_strerror(rc, text, sizeof(text));
        NSString *error = [NSString stringWithFormat:@"MPEG-TS 打开/探测失败：%s (%d)", text, rc];
        e.noteFor(reader.generation, error.UTF8String);
        std::lock_guard<std::mutex> lock(e.mutex);
        if (e.generation.load() == reader.generation) e.lastError = error.UTF8String;
    }
    avformat_close_input(&fmt);
    // Custom AVIO remains owned by us; FFmpeg may have replaced its buffer.
    av_freep(&io->buffer); avio_context_free(&io);
    if (reader.receiveError) {
        NSString *error = [NSString stringWithFormat:@"recv 失败：errno=%d，%@", reader.receiveError,
            [NSString stringWithUTF8String:strerror(reader.receiveError)] ?: @"未知错误"];
        std::lock_guard<std::mutex> lock(e.mutex);
        if (e.generation.load() == reader.generation) e.lastError = error.UTF8String;
        NSLog(@"[OBSBridge] %@", error);
    }
}

void networkError(Engine &e, uint64_t g, const char *operation, int code) {
    NSString *message = [NSString stringWithFormat:@"%s 失败：errno=%d，%s", operation, code, strerror(code)];
    std::lock_guard<std::mutex> lock(e.mutex);
    if (e.generation.load() != g) return;
    e.message = message.UTF8String; e.lastError = e.message;
    e.listening = false; e.enabled = false;
    NSLog(@"[OBSBridge] %@", message);
}
void serve(NSString *ip, NSString *peer, uint64_t g) {
    auto &e = engine();
    if (!e.active(g)) return;
    sockaddr_in addr{}; addr.sin_len = sizeof(addr); addr.sin_family = AF_INET;
    addr.sin_port = htons(OB_PORT);
    in_addr allowed{};
    if (inet_pton(AF_INET, ip.UTF8String, &addr.sin_addr) != 1 ||
        inet_pton(AF_INET, peer.UTF8String, &allowed) != 1) {
        networkError(e, g, "IPv4", EINVAL); return;
    }
    int listener = socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) { networkError(e, g, "socket", errno); return; }
    int yes = 1; setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    if (bind(listener, (sockaddr *)&addr, sizeof(addr))) {
        int code = errno; close(listener); networkError(e, g, "bind", code); return;
    }
    if (listen(listener, 2)) {
        int code = errno; close(listener); networkError(e, g, "listen", code); return;
    }
    if (!nonblocking(listener)) {
        int code = errno; close(listener); networkError(e, g, "fcntl listener", code); return;
    }
    if (e.active(g)) e.listening = true;
    while (e.active(g)) {
        e.noteFor(g, "TCP 已监听，等待 OBS 连接（与摄像头/音频 Hook 独立）");
        sockaddr_in remote{}; socklen_t len = sizeof(remote);
        Reader reader(g); reader.fd = accept(listener, (sockaddr *)&remote, &len);
        if (reader.fd < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) { waitNetwork(); continue; }
            networkError(e, g, "accept", errno); break;
        }
        char actual[INET_ADDRSTRLEN]{};
        inet_ntop(AF_INET, &remote.sin_addr, actual, sizeof(actual));
        { std::lock_guard<std::mutex> lock(e.mutex); e.lastPeer = actual; }
        if (remote.sin_addr.s_addr != allowed.s_addr) { ++e.rejected; continue; }
        if (!nonblocking(reader.fd)) {
            networkError(e, g, "fcntl connection", errno); break;
        }
        ++e.accepted;
        { std::lock_guard<std::mutex> lock(e.mutex); if (e.active(g)) e.clearLocked(); }
        @autoreleasepool { decodeConnection(reader); }
        { std::lock_guard<std::mutex> lock(e.mutex); if (e.active(g)) e.clearLocked(); }
    }
    close(listener);
    if (e.generation.load() == g) e.listening = false;
}

}

BOOL OBEnabled(void) { return engine().enabled.load(); }
void OBStart(NSString *ip, NSString *peer) {
    OBStop(); auto &e = engine();
    uint64_t g = ++e.generation;
    e.videos = 0; e.audios = 0; e.bytes = 0; e.accepted = 0; e.rejected = 0;
    e.published = 0; e.publishFailed = 0;
    e.ticks = 0; e.clockResets = 0; e.queueDrops = 0;
    e.budgetDrops = 0; e.hardwareFrames = 0; e.softwareFrames = 0;
    { std::lock_guard<std::mutex> lock(e.mutex);
      e.lastError.clear(); e.lastPeer.clear(); e.message = "启动请求已处理，正在创建 TCP 接收端"; }
    OBBusEnable(YES); e.enabled = true;
    dispatch_async(e.queue, ^{ @autoreleasepool { serve(ip, peer, g); } });
}
void OBStop(void) {
    auto &e = engine(); e.enabled = false; e.listening = false; ++e.generation;
    std::lock_guard<std::mutex> lock(e.mutex);
    OBBusEnable(NO); e.clearLocked(); e.message = "已停止接收和共享输出，系统节点透传真实输入";
}
void OBProducerTick(void) {
    OBBusHeartbeat(); auto &e = engine();
    ++e.ticks;
    if (!e.enabled.load()) { OBBusEnable(NO); return; }
    std::lock_guard<std::mutex> lock(e.mutex);
    double now = OBNow();
    while (!e.images.empty() && e.images.front()->due <= now) {
        e.current = e.images.front(); e.images.pop_front();
    }
    if (e.current && e.current != e.publishedImage && now - e.current->due < .5) {
        if (OBBusPublishVideo(e.current->pixel, e.current->due)) {
            ++e.published; e.publishedImage = e.current;
        } else ++e.publishFailed;
    }
}
NSString *OBStatus(void) {
    auto &e = engine(); std::lock_guard<std::mutex> lock(e.mutex);
    NSString *message = [NSString stringWithUTF8String:e.message.c_str()] ?: @"状态编码无效";
    NSString *lastError = e.lastError.empty() ? @"无" : [NSString stringWithUTF8String:e.lastError.c_str()];
    NSString *lastPeer = [NSString stringWithUTF8String:e.lastPeer.c_str()] ?: @"";
    double headWait = e.images.empty() ? 0 : (e.images.front()->due - OBNow()) * 1000;
    return [NSString stringWithFormat:@"OBSBridge %@ · SpringBoard 接收层\n%@\nTCP 监听 %@；收包 %llu 字节\n连接 %llu / 拒绝 %llu；最近来源 %@\n解码：视频 %llu / 音频 %llu\n共享发布 %llu / 发布失败 %llu\n调度 %llu；队列 %zu / 队首 %.0f ms\n丢帧 %llu / 时钟重置 %llu\n最近网络错误：%@\n%@\n\n%@",
        OB_VERSION, message, e.listening ? @"是" : @"否",
        (unsigned long long)e.bytes.load(), (unsigned long long)e.accepted.load(),
        (unsigned long long)e.rejected.load(), lastPeer,
        (unsigned long long)e.videos.load(), (unsigned long long)e.audios.load(),
        (unsigned long long)e.published.load(), (unsigned long long)e.publishFailed.load(),
        (unsigned long long)e.ticks.load(), e.images.size(), headWait,
        (unsigned long long)e.queueDrops.load(), (unsigned long long)e.clockResets.load(),
        lastError ?: @"错误编码无效", OBBusProducerStatus(),
        [NSString stringWithFormat:@"%@\n节流丢帧 %llu；硬解帧 %llu / 软解帧 %llu\n画质档 %@；热状态 %ld\n\n%@",
            OBMediaStatus(), (unsigned long long)e.budgetDrops.load(), (unsigned long long)e.hardwareFrames.load(),
            (unsigned long long)e.softwareFrames.load(), OBBusVideoProfile() ? @"720p/30fps" : @"540p/30fps",
            (long)NSProcessInfo.processInfo.thermalState, OBLiveAudioStatus()]];
}
